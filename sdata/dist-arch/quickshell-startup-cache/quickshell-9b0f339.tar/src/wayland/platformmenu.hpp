#pragma once

void installPlatformMenuHook();

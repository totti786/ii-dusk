#include "cliprect.hpp" // NOLINT
